import type { AssignmentIdentity } from "../../domain/assignment";

export type AgentAuthorityCapability =
  | "workspace.list"
  | "workspace.read"
  | "workspace.search"
  | "verification.run"
  | "workspace.write"
  | "workspace.shell";

export type AgentWorkspaceScope =
  | Readonly<{
      workspaceId: string;
      mode: "subtree";
      root: string;
      access: "read" | "write";
    }>
  | Readonly<{
      workspaceId: string;
      mode: "exact";
      root: string;
      paths: readonly string[];
      access: "read" | "write";
    }>;

// Only a granted authority (the response side of `AgentAuthorityPort`)
// carries where its restriction came from; a caller's own narrowing request
// never does — it asks for a scope, it does not get to assert its
// provenance. Optional so a record produced before this field existed still
// matches the type: `undefined` is read back as unknown provenance, never
// defaulted to "task-grant" (see `codex-agent-workspace-probe.ts`'s
// `participant()`).
export type GrantedAgentWorkspaceScope =
  | Readonly<{
      workspaceId: string;
      mode: "subtree";
      root: string;
      access: "read" | "write";
      restrictionSource?: "task-grant" | "owner-restriction" | undefined;
    }>
  | Readonly<{
      workspaceId: string;
      mode: "exact";
      root: string;
      paths: readonly string[];
      access: "read" | "write";
      restrictionSource?: "task-grant" | "owner-restriction" | undefined;
    }>;

export type GrantedAgentWorkspaceExclusion = Readonly<{
  workspaceId: string;
  path: string;
  restrictionSource?:
    "computer-approval" | "task-grant" | "owner-restriction" | undefined;
}>;

export type AgentAuthorityNarrowing = Readonly<{
  workspaces: readonly AgentWorkspaceScope[];
  excludedPaths?:
    | readonly Readonly<{
        workspaceId: string;
        path: string;
      }>[]
    | undefined;
  capabilities: readonly AgentAuthorityCapability[];
  network: "none" | "loopback" | "approved";
  commands: "none" | "verification" | "workspace";
}>;

export type AgentDelegationRequest = Readonly<{
  identity: AssignmentIdentity;
  parentParticipantId: string;
  participantId: string;
  role: "agent" | "critic";
  mutationOwnership: "none" | "task";
  narrowing?: AgentAuthorityNarrowing;
}>;

export type DelegatedAgentAuthority = Readonly<{
  authorityId: string;
  participantId: string;
  parentParticipantId: string;
  role: "agent" | "critic";
  mutationOwnership: "none" | "task";
  ownerId: string;
  sessionId: string;
  taskId: string;
  taskEpoch: number;
  computerId: string;
  computerGeneration: number;
  workspaces: readonly GrantedAgentWorkspaceScope[];
  excludedPaths: readonly GrantedAgentWorkspaceExclusion[];
  capabilities: readonly AgentAuthorityCapability[];
  network: "none" | "loopback" | "approved";
  commands: "none" | "verification" | "workspace";
  expiresAt: number;
  // Absent on a record produced before provenance existed. See
  // `GrantedAgentWorkspaceScope` above.
  authorityShapeVersion?: 1 | undefined;
}>;

// "unverified-provenance": the denying restriction came from a record whose
// provenance could not be verified (no shape version, or no declared
// source) — reported as exactly that, never as "task-grant".
export type AgentAuthorityFailureSource =
  | "computer-approval"
  | "task-admission"
  | "task-grant"
  | "owner-restriction"
  | "unverified-provenance"
  | "role"
  | "computer-policy"
  | "native-host"
  | "authority-store";

export type AgentAuthorityDecision =
  | Readonly<{ ok: true; value: DelegatedAgentAuthority }>
  | Readonly<{
      ok: false;
      error: Readonly<{
        code: "AGENT_AUTHORITY_DENIED" | "AGENT_AUTHORITY_UNAVAILABLE";
        source: AgentAuthorityFailureSource;
        retry: "never";
      }>;
    }>;

export interface AgentAuthorityPort {
  delegate(request: AgentDelegationRequest): Promise<AgentAuthorityDecision>;
}
