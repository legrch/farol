import { EventEmitter } from "node:events";
import { PassThrough, Writable } from "node:stream";
import type { ChildProcessWithoutNullStreams } from "node:child_process";
import { describe, expect, it } from "vitest";

import { SharedCodexProxyHost } from "../../src/modules/chat/infra/native/shared-codex-proxy-host";

/** In-memory wire contract only: no process, socket, native cleanup or live host evidence. */
function memoryHost(rejectHandshake = false) {
  const received: Array<Record<string, any>> = [];
  const output = new PassThrough();
  let experimental = false;
  const events = new EventEmitter();
  const child = Object.assign(events, {
    stdout: output,
    stderr: new PassThrough(),
    exitCode: null as number | null,
    signalCode: null as string | null,
    stdin: new Writable({
      write(chunk, _encoding, done) {
        const request = JSON.parse(chunk.toString()) as Record<string, any>;
        received.push(request);
        done();
        if (request.id === undefined) return;
        queueMicrotask(() => {
          let response: unknown;
          if (request.method === "initialize") {
            experimental =
              request.params.capabilities?.experimentalApi === true;
            response = rejectHandshake
              ? {
                  error: { code: -32600, message: "fixture handshake refusal" },
                }
              : {
                  result: {
                    codexHome: "/fixture/codex",
                    platformFamily: "unix",
                    platformOs: "macos",
                    userAgent: "memory-fixture",
                  },
                };
          } else {
            response = experimental
              ? { result: { data: [], nextCursor: null } }
              : {
                  error: {
                    code: -32600,
                    message: "project/list requires experimentalApi capability",
                  },
                };
          }
          output.write(
            JSON.stringify({ id: request.id, ...(response as object) }) + "\n",
          );
        });
      },
    }),
    kill(signal: string) {
      this.signalCode = signal;
      events.emit("exit", null, signal);
      return true;
    },
  });
  let launches = 0;
  const host = new SharedCodexProxyHost(() => {
    launches++;
    return child as unknown as ChildProcessWithoutNullStreams;
  }, "/fixture/codex");
  return { host, received, launchCount: () => launches };
}

describe("shared Codex handshake, in-memory protocol boundary", () => {
  it("negotiates the experimental API required by existing project selection", async () => {
    const { host, received } = memoryHost();
    try {
      await expect(
        host.request("project/list", { cursor: null }),
      ).resolves.toEqual({ data: [], nextCursor: null });
      expect(received[0]).toMatchObject({
        method: "initialize",
        params: { capabilities: { experimentalApi: true } },
      });
      expect(received.map((frame) => frame.method)).toEqual([
        "initialize",
        "initialized",
        "project/list",
      ]);
    } finally {
      host.close();
    }
  });

  it("does not turn capability negotiation into a grant, model turn or reconnect", async () => {
    const { host, received, launchCount } = memoryHost();
    try {
      await host.request("project/list", { cursor: null });
      await host.request("project/list", { cursor: null });
      expect(launchCount()).toBe(1);
      expect(
        received.filter((frame) => frame.method === "initialize"),
      ).toHaveLength(1);
      expect(
        received.every((frame) =>
          ["initialize", "initialized", "project/list"].includes(frame.method),
        ),
      ).toBe(true);
      expect(received[0]?.params.capabilities).toEqual({
        experimentalApi: true,
      });
    } finally {
      host.close();
    }
  });

  it("does not retry a refused handshake using reduced capabilities", async () => {
    const { host, received, launchCount } = memoryHost(true);
    try {
      await expect(
        host.request("project/list", { cursor: null }),
      ).rejects.toThrow();
      expect(launchCount()).toBe(1);
      expect(received.map((frame) => frame.method)).toEqual(["initialize"]);
    } finally {
      host.close();
    }
  });
});
