import { spawn } from "node:child_process";
import { describe, expect, it } from "vitest";

import { SharedCodexProxyHost } from "../../src/modules/chat/infra/native/shared-codex-proxy-host";
import { HandoffNotSubmittedError } from "../../src/modules/chat/app/service/persistent-codex-handoff";

/** Protocol fixture only. Never launches Codex, opens a socket or runs a model. */
const GATED_SERVER = String.raw`
let buffered = "";
let experimental = false;
let initialized = false;
let initializeCount = 0;
let mutationCount = 0;
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffered += chunk;
  for (;;) {
    const end = buffered.indexOf("\n");
    if (end < 0) return;
    const request = JSON.parse(buffered.slice(0, end));
    buffered = buffered.slice(end + 1);
    if (request.method === "initialized") { initialized = true; continue; }
    let response;
    if (request.method === "initialize") {
      initializeCount++;
      experimental = request.params.capabilities?.experimentalApi === true;
      response = process.env.REJECT_HANDSHAKE === "1"
        ? { error: { code: -32600, message: "handshake rejected" } }
        : { result: { codexHome: "/fixture/codex", platformFamily: "unix", platformOs: "macos", userAgent: "fixture-only" } };
    } else if (request.method === "project/list") {
      response = !experimental || !initialized
        ? { error: { code: -32600, message: "project/list requires experimentalApi capability" } }
        : { result: { data: [], nextCursor: null, proof: { experimental, initialized, initializeCount, mutationCount } } };
    } else {
      mutationCount++;
      response = { error: { code: -32601, message: "unexpected method" } };
    }
    process.stdout.write(JSON.stringify({ id: request.id, ...response }) + "\n");
  }
});
`;

function fixture(rejectHandshake = false) {
  let launches = 0;
  const host = new SharedCodexProxyHost(() => {
    launches++;
    return spawn(process.execPath, ["-e", GATED_SERVER], {
      stdio: ["pipe", "pipe", "pipe"],
      env: { REJECT_HANDSHAKE: rejectHandshake ? "1" : "0" },
    });
  }, "/fixture/codex");
  return { host, launchCount: () => launches };
}

describe("shared Codex used-capability handshake", () => {
  it("opts into the experimental project API once before read-only project selection", async () => {
    const { host, launchCount } = fixture();
    try {
      for (let i = 0; i < 2; i++) {
        expect(await host.request("project/list", { cursor: null })).toEqual({
          data: [],
          nextCursor: null,
          proof: {
            experimental: true,
            initialized: true,
            initializeCount: 1,
            mutationCount: 0,
          },
        });
      }
      expect(launchCount()).toBe(1);
    } finally {
      expect(await host.closeAndWait()).toBe(true);
    }
  });

  it("does not retry a rejected handshake without capabilities or launch a replacement", async () => {
    const { host, launchCount } = fixture(true);
    try {
      await expect(
        host.request("project/list", { cursor: null }),
      ).rejects.toBeInstanceOf(HandoffNotSubmittedError);
      expect(launchCount()).toBe(1);
    } finally {
      expect(await host.closeAndWait()).toBe(true);
    }
  });
});
